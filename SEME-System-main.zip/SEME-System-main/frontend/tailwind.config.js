/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./src/pages/Home.js", "./src/components/EntryItem.js"],
    theme: {
        extend: {},
    },
    plugins: [],
}
